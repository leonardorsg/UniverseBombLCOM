#ifndef _DDEKIT_DDEKIT_H
#define _DDEKIT_DDEKIT_H
void ddekit_init(void);

#endif

