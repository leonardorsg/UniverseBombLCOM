#define DDEKIT_INLINE __inline__ __attribute__((always_inline))

