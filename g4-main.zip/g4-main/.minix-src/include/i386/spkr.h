/*	$NetBSD: spkr.h,v 1.4 1998/04/15 21:40:27 drochner Exp $	*/

/*
 * spkr.h -- interface definitions for speaker ioctl()
 */

#ifndef _I386_SPKR_H_
#define _I386_SPKR_H_

#include <sys/ioctl.h>
#include <dev/isa/spkrio.h>

#endif /* _I386_SPKR_H_ */
