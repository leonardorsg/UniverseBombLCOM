/*	$NetBSD: ieee.h,v 1.2 2003/02/26 21:29:01 fvdl Exp $	*/

#include <x86/ieee.h>
