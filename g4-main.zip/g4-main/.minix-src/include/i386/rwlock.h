/*	$NetBSD: rwlock.h,v 1.2 2007/02/09 21:55:05 ad Exp $	*/

#include <x86/rwlock.h>
