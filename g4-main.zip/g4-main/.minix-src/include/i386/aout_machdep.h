/*	$NetBSD: aout_machdep.h,v 1.8 2003/02/26 21:28:59 fvdl Exp $	*/

#include <x86/aout_machdep.h>
