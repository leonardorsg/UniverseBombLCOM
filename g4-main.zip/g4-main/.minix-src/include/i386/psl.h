/*	$NetBSD: psl.h,v 1.35 2003/02/26 21:29:03 fvdl Exp $	*/

#include <x86/psl.h>
