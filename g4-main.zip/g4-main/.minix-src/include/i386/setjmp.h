/*	$NetBSD: setjmp.h,v 1.2 1998/09/14 21:31:52 thorpej Exp $	*/

/*
 * machine/setjmp.h: machine dependent setjmp-related information.
 */

#define	_JBLEN	13		/* size, in longs, of a jmp_buf */
