/*	$NetBSD: mtrr.h,v 1.8 2003/02/26 21:29:02 fvdl Exp $	*/

#include <x86/mtrr.h>
