/*	$NetBSD: lock.h,v 1.9 2003/02/27 00:12:22 fvdl Exp $	*/

#include <x86/lock.h>
